 <footer class="footer">
     <!-- Start Footer Bottom -->
     <div class="footer-bottom">
         <div class="container">
             <div class="inner-content">
                 <div class="row align-items-center">
                     <div class="col-lg-4 col-12">
                         <div class="payment-gateway">
                             <span>PT.NUR LISAN SAKTI</span>
                         </div>
                     </div>
                     <div class="col-lg-4 col-12">
                         <div class="copyright">
                             <p>Copyright@2025</p>
                         </div>
                     </div>
                     <div class="col-lg-4 col-12">
                         <ul class="socila">
                             <li>
                                 <span>Ikuti Kami di:</span>
                             </li>
                             <li><a href="<?= getKontak('facebook') ?? 'javascript:void(0)' ?>"><i class="lni lni-facebook-filled"></i></a></li>
                             <li><a href="<?= getKontak('instagram') ?? 'javascript:void(0)' ?>"><i class="lni lni-instagram"></i></a></li>
                             <li><a href="<?= getKontak('youtube') ?? 'javascript:void(0)' ?>"><i class="lni lni-youtube"></i></a></li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <!-- End Footer Bottom -->
 </footer>