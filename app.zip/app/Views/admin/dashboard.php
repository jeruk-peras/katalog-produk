<?= $this->extend('admin/layout/template'); ?>
<?= $this->section('content'); ?>
<div class="page-content">
    <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">Selamat Datang di Dashboard Admin!</h4>
        <p>Halo, selamat datang di halaman dashboard. Silakan gunakan menu di samping untuk mengelola data aplikasi.</p>
    </div>
</div>
<?= $this->endSection(); ?>